<?php 
include "practice1.php";
if(isset($_POST['uname'])&&isset($_POST['pwd']))
{
	$a=$_POST['uname'];
	$b=$_POST['pwd'];
	$temp="select * from adminaccount where username='".$a."'and password='".$b."'";
	$query=mysqli_query($con,$temp);
	$st=mysqli_num_rows($query);
		if($st==1)
		{
			 echo "Username :";
			  echo $a;
			echo "<br>";
			/* echo "Password : ";
			  echo $b;*/
		

		}
	else
	{
		echo "<script>
		alert('Invalid Username and passwod pair');
		</script>";
		header("location:adminlogin.php");
}

}


?>

<?php 
  echo "Total Record Fetch=";

			$temp="SELECT COUNT(*) as count FROM registration where status = 0";
			$rs=mysqli_query($con,$temp);
			while($row=mysqli_fetch_assoc($rs))
			{
				$count = $row['count'];
			}

			echo $count;

?>

<html>
<body>
<br><br><br> 
<h3> List Of Staff </h3>
<table border="1"> 
<tr>
<th>id</th>
<th> Name</th>
<th>User Name </th>
<th>Email id</th>
<th> Detail</th>
</tr>
<?php
$sql="select * from staff";
$query=mysqli_query($con,$sql);
$i=0;
while($row=mysqli_fetch_assoc($query))
{
?>


<tr>
	<td><?php echo $row['staff_id']; ?></td>
	<td><?php echo $row['s_name']; ?></td>
	<td><?php echo $row['s_email']; ?></td>
	<td><?php echo $row['s_mobile']; ?></td> 
	<td><a href="users.php?id= <?php echo $row['staff_id']; ?>" >Details</a></td> 
	>


<?php 
$i++;

}?>

</table>
</body>
</html>




























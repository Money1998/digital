<?php include "practice1.php"; 


$sql="UPDATE registration SET status=0 where id='".$_GET['id']."'";
mysqli_query($con,$sql);


header("location:login_process.php");


?>
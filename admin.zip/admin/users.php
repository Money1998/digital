<?php include "practice1.php";?> 
<html>
<head></head>
<body>
<table border="1">
<tr>
<th>id</th>
<th>Name</th>
<th>Email </th>
<th>Mobile No.</th>
<th>Action</th>
</tr>

<?php

$sql="select * from personal where staff_id='".$_GET['id']."'";
$query=mysqli_query($con,$sql);
while($row=mysqli_fetch_assoc($query))
{
?>
<tr>
	<td><?php echo $row['c_id']; ?></td>
	<td><?php echo $row['c_name']; ?></td>
	<td><?php echo $row['c_email']; ?></td>
	<td><?php echo $row['c_phone']; ?></td> 
	<td><a href="b.php?id= <?php echo $row['stu_id']; ?>" >Details</a></td>
</tr>
<?php 
$i++;
}?>

</table>
</body>
</html>

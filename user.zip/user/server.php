
<?php
session_start();
include "practice1.php";

$errors = array(); 


if (isset($_POST["submit1"])) {

 
	 $name = $_POST["name"];
  $username = $_POST["username"];
  $email =  $_POST["email"];
  $password_1 = $_POST["pass"];
  $password_2 =  $_POST["repass"];
 
  if (empty($name)) { array_push($errors, "Fullname is required"); }
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password_1)) { array_push($errors, "Password is required"); }
  if ($password_1 != $password_2) {
	array_push($errors, "The two passwords do not match");
  }

  $user_check = "SELECT * FROM registration WHERE username='".$username."' OR email='".$email."' LIMIT 1";
  $result = mysqli_query($con, $user_check);
  $user = mysqli_fetch_assoc($result);
  
  if ($user) { 
    if ($user["username"] == $username) {
      array_push($errors, "Username already exists");
    }

    if ($user["email"] == $email) {
      array_push($errors, "email already exists");
    }
  }

 
  if (count($errors) == 0) {
  	$password =$password_1; 

  	$query = "INSERT INTO registration (name, email, password,username) 
  			  VALUES('".$name."', '".$email."', '".$password."','".$username."')";
  	mysqli_query($con, $query);
  	$_SESSION["username"] = $username;
  	$_SESSION["success"] = "You are now logged in";
  	header("location: userlogin.php?signup=success");
  }
}?>
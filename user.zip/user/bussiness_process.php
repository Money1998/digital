
<?php
session_start();
include "practice1.php";

$errors = array(); 


if (isset($_POST["sb1"])) {

	 $name = $_POST["bname"];
  $contact = $_POST["bphone"];
  $email =  $_POST["bemail"];
  $state = $_POST["bstate"];
  $city =  $_POST["bcity"];
  $add =  $_POST["badd"];
  $pin = $_POST["bpin"];
  $fax = $_POST["bfax"];
  $web = $_POST["bweb"];

 
  if (empty($name)) { array_push($errors, "Name is required"); }
  if (empty($contact)) { array_push($errors, "Contact is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($state)) { array_push($errors, "State is required"); }
if (empty($city)) { array_push($errors, "City is required"); }
if (empty($add)) { array_push($errors, "Address is required"); }
if (empty($pin)) { array_push($errors, "Pincode is required"); }
if (empty($fax)) { array_push($errors, "Fax is required"); }
if (empty($web)) { array_push($errors, "Website is required"); }



if (count($errors) == 0) {
  

  	$query = "INSERT INTO bussiness (b_name,b_email,b_phone,b_state,b_city,b_add,b_pin,b_fax,b_web,staff_id) 
  			  VALUES('".$name."', '".$email."', '".$contact."','".$state."','".$city."','".$add."','".$pin."','".$fax."','".$web."','".$_SESSION['id']."')";
  	mysqli_query($con, $query);

    header("location: plan.php");
}
}?>
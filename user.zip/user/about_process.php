
<?php
session_start();
include "practice1.php";

$errors = array(); 


if (isset($_POST["sb3"])) {

	 $about = $_POST["about"];
  $spec = $_POST["a_spec"];

 
  if (empty($about)) { array_push($errors, "Name is required"); }
  if (empty($spec)) { array_push($errors, "Contact is required"); }
 

if (count($errors) == 0) {
  

  	$query = "INSERT INTO about (a_about_us,a_speciality,staff_id) 
  			  VALUES('".$about."', '".$spec."','".$_SESSION['id']."')";
  	mysqli_query($con, $query);
echo $query;
    //header("location: service.php");
}
}?>

<?php
session_start();
include "practice1.php";

$errors = array(); 


if (isset($_POST["sb4"])) {

	$service = $_POST["service"];
  $offer = $_POST["offer"];
  $dis =  $_POST["discount"];
  $sd = $_POST["sdate"];
  $ed =  $_POST["edate"];

 
  if (empty($service)) { array_push($errors, "Service is required"); }
  if (empty($offer)) { array_push($errors, "Offer is required"); }
  if (empty($dis)) { array_push($errors, "Discount is required"); }
  if (empty($sd)) { array_push($errors, "Start Date is required"); }
if (empty($ed)) { array_push($errors, "End date is required"); }


if (count($errors) == 0) {
  

  	$query = "INSERT INTO service (s_name,s_offer,s_discount,s_start,s_expire,staff_id) 
  			  VALUES('".$service."', '".$offer."', '".$dis."','".$sd."','".$ed."','".$_SESSION['id']."')";
  	mysqli_query($con, $query);
echo $query;
    //header("location: plan.php");
}
}?>

<?php
session_start();
include "practice1.php";

$errors = array(); 


if (isset($_POST["sb"])) {

	 $name = $_POST["name"];
  $contact = $_POST["contact"];
  $email =  $_POST["email"];
  $state = $_POST["state"];
  $city =  $_POST["city"];
  $add =  $_POST["address"];
  $pin = $_POST["pincode"];

 
  if (empty($name)) { array_push($errors, "Name is required"); }
  if (empty($contact)) { array_push($errors, "Contact is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($state)) { array_push($errors, "State is required"); }
if (empty($city)) { array_push($errors, "City is required"); }
if (empty($add)) { array_push($errors, "Address is required"); }
if (empty($pin)) { array_push($errors, "Pincode is required"); }



if (count($errors) == 0) {
  

  	$query = "INSERT INTO personal_profile (c_name,c_email,c_phone,c_state,c_city,c_add,c_pin,staff_id) 
  			  VALUES('".$name."', '".$email."', '".$contact."','".$state."','".$city."','".$add."','".$pin."','".$_SESSION['id']."')";
  	mysqli_query($con, $query);

    header("location: bussiness.php");
}
}?>
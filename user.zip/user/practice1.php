<?php 

ob_start();


define('hostname','localhost');
define('username','root');
define('password','');
define('dbname','project2019');


	$con=mysqli_connect(hostname,username,password,dbname) or die("can not connect with server");



?>
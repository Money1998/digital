<?php 
session_start();

include "practice1.php";
if(isset($_POST['uname']) && isset($_POST['pwd']))
{
	$a=$_POST['uname'];
	$b=$_POST['pwd'];
	echo $temp="SELECT * from staff where s_name='".$a."' AND s_password='".$b."'";
		$query=mysqli_query($con,$temp);
	
		if($st=mysqli_fetch_assoc($query))
		{
			$_SESSION['name']=$_POST['uname'];
			$_SESSION['id']=$st['staff_id'];
			//echo $_SESSION['id'];
			//setcookie('user',$a,time()+60);
			header("location:personal.php?login1=success");

		}
	else
	{	
	
	header("location:emp1.php?login=success");
	}

}
?>




<?php
session_start();
include "practice1.php";
$date=date('y-m-d',time());
$d=date('y-m-d',strtotime('+1 month'));
$q1 = $_POST['radios'];
switch ($q1) 
{
	case "silver":
					$query1 = "insert into plan (p_name,p_type,p_price,p_start,p_end,staff_id) values('".$q1."','bulk sms',1000,'".$date."','".$d."','".$_SESSION['id']."')";
					mysqli_query($con,$query1);
					echo $query1;
					header("location:photo.php");
					break;
	case "gold":
					$query1 = "insert into plan (p_name,p_type,p_price,p_start,p_end,staff_id) values('".$q1."','bulk sms - whatsapp - gmail',1500,'".$date."','".$d."','".$_SESSION['id']."')";
					mysqli_query($con,$query1); 
					header("location:photo.php");
				
					echo $query1;
					break;

	case "diamond":
					$query1 = "insert into plan (p_name,p_type,p_price,p_start,p_end,staff_id) values('".$q1."','bulk sms - social media - gmail',2000,'".$date."','".$d."','".$_SESSION['id']."')";
					mysqli_query($con,$query1);
					header("location:photo.php");
				
					echo $query1;
					break;	
	default:
					header("location:plan.php");
				
					echo "error";
					break;
}
?>
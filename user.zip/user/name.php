<?php 
include "practice1.php";
if(isset($_POST['uname'])&&isset($_POST['pwd']))
{
	$a=$_POST['uname'];
	$b=$_POST['pwd'];
	$temp="select * from registration where username='".$a."'and password='".$b."'";
	$query=mysqli_query($con,$temp);
	$st=mysqli_num_rows($query);
		if($st==1)
		{
			 echo "Username :";
			  echo $a;
			echo "<br>";
			 echo "Password : ";
			  echo $b;
		

		}
	else
	{
		echo "hi";
}

}


?>
